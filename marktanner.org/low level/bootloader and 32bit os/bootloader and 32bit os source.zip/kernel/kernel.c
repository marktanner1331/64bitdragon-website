#include "../drivers/screen.h"

void main()
{
	clearScreen();
	print("This is awesome!");
}
