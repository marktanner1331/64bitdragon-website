void memCopy(char* source, char* dest, int numBytes);
