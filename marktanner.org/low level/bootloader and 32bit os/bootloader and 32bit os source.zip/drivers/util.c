// Copy bytes from one place to another.
void memCopy(char* source, char* dest, int numBytes)
{
	int i;
	for(i = 0;i < numBytes;i++)
	{
		*(dest + i) = *(source + i);
	}
}
