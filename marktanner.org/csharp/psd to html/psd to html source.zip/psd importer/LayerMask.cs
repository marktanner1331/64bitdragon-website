﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace psd_importer
{
    class LayerMask
    {
        public int left = 0;
		public int right = 0;
		public int top = 0;
        public int bottom = 0;
    }
}
