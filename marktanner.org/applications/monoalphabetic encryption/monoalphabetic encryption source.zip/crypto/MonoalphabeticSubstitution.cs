﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace crypto
{
    public class MonoalphabeticSubstitution
    {
        /// <summary>
        /// performs a general substitution, replacing each character one at a time
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="plainText"></param>
        /// <param name="plainTextAlphabet"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public static T[] encrypt<T>(T[] plainText, T[] plainTextAlphabet, T[] key)
        {
            Dictionary<T, T> substitutionDict = Primitives.createSubstitutionDictionary(plainTextAlphabet, key);

            return Primitives.performSubstitution(plainText, substitutionDict);
        }

        /// <summary>
        /// performs a general reverse substitution, replacing each character one at a time
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="cipherText"></param>
        /// <param name="plainTextAlphabet"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public static T[] decrypt<T>(T[] cipherText, T[] plainTextAlphabet, T[] key)
        {
            Dictionary<T, T> substitutionDict = Primitives.createSubstitutionDictionary(key, plainTextAlphabet);

            return Primitives.performSubstitution(cipherText, substitutionDict);
        }
    }
}
