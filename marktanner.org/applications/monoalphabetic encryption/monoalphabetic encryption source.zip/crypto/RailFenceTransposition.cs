﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace crypto
{
    //http://en.wikipedia.org/wiki/Rail_Fence_Cipher
    class RailFenceTransposition
    {
        public static T[] encrypt<T>(T[] plainText, int numLines)
        {
            T[][] lines = new T[numLines][];

            //calculate the sizes of the lines
            int remainder = plainText.Length % numLines;
            int quotient = (plainText.Length - remainder) / numLines;

            for (int i = 0; i < numLines; i++)
            {
                if (remainder > 0)
                {
                    lines[i] = new T[quotient + 1];
                    remainder--;
                }
                else
                {
                    lines[i] = new T[quotient];
                }
            }

            //initialize the indices array
            int[] charIndices = new int[numLines];
            Array.Clear(charIndices, 0, charIndices.Length);

            for (int i = 0; i < plainText.Length; i++)
            {
                int lineIndex = i % numLines;
                lines[lineIndex][charIndices[lineIndex]] = plainText[i];
                charIndices[lineIndex]++;
            }

            return Primitives.combineArrays(lines);
        }

        public static T[] decrypt<T>(T[] cipherText, int numLines)
        {
            T[][] lines = new T[numLines][];
            T[] plainText = new T[cipherText.Length];

            //calculate the sizes of the lines
            int remainder = plainText.Length % numLines;
            int quotient = (plainText.Length - remainder) / numLines;
            int offset = 0;

            for (int i = 0; i < numLines; i++)
            {
                int length;
                if (remainder > 0)
                {
                    
                    length = quotient + 1;
                    remainder--;
                }
                else
                {
                    length = quotient;
                }

                lines[i] = Primitives.subArray(cipherText, offset, length);
                offset += length;
            }

            //initialize the indices array
            int[] charIndices = new int[numLines];
            for (int i = 0; i < numLines; i++)
            {
                charIndices[i] = 0;
            }

            //build the plaintext by alernating between the lines
            for (int i = 0; i < plainText.Length; i++)
            {
                int lineIndex = i % numLines;
                plainText[i] = lines[lineIndex][charIndices[lineIndex]];
                charIndices[lineIndex]++;
            }

            //return the plaintext as a string
            return plainText;
        }
    }
}
