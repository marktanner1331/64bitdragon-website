﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace crypto
{
    public class CipherKeyFactory
    {
        /// <summary>
        /// generates a monoalphabetic cipher from the source alphabet, basically just returns a shuffled
        /// version of the source
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="sourceAlphabet"></param>
        /// <returns></returns>
        public static T[] getMonoalphabeticCipherKey<T>(T[] sourceAlphabet)
        {
            return Primitives.knuthShuffle(sourceAlphabet);
        }

        /// <summary>
        /// generates a caesar cipher alphabet from the source alphabet
        /// basically just shifts it by a random amount
        /// </summary>
        /// <param name="sourceAlphabet"></param>
        /// <returns></returns>
        public static T[] getCaesarCipherKey<T>(T[] sourceAlphabet)
        {
            Random rand = new Random();
            int shiftAmount = rand.Next(1, sourceAlphabet.Length);

            return Primitives.shift(sourceAlphabet, shiftAmount);
        }

        /// <summary>
        /// generates a cipher alphabet using the keyword as the first part and filling in the rest 
        /// with the remaining characters in the alphabet
        /// the source alphabet must contain all characters used in the key phrase, e.g. including punctuation
        /// this function will crash if the keyphrase is empty
        /// </summary>
        /// <param name="keyPhrase"></param>
        /// <param name="sourceAlphabet"></param>
        /// <returns></returns>
        public static T[] getKeyPhraseCipherKey<T>(T[] keyPhrase, T[] sourceAlphabet) where T : IComparable<T>
        {
            HashSet<T> usedCharacters = new HashSet<T>();
            T[] cipherAlphabet = new T[sourceAlphabet.Length];
            int a = 0;

            //fill the cipher alphabet with the keyphrase, removing duplicates
            for (int i = 0; i < keyPhrase.Length; i++)
            {
                if (usedCharacters.Contains(keyPhrase[i]) == false)
                {
                    cipherAlphabet[a] = keyPhrase[i];

                    usedCharacters.Add(keyPhrase[i]);
                    a++;
                }
            }

            //if the keyphrase is empty, this will crash
            T lastChar = cipherAlphabet[a - 1];

            //find the point in the source alphabet where we can start taking characters from
            int b = 0;
            for (int i = 0; i < sourceAlphabet.Length; i++)
            {
                if (sourceAlphabet[i].Equals(lastChar))
                {
                    break;
                }

                b++;
            }

            //now fill in the rest of the cipher alphabet
            while (a < cipherAlphabet.Length)
            {
                //get b to point to the next character in the source alphabet
                b += 1;
                b %= sourceAlphabet.Length;

                if (usedCharacters.Contains(sourceAlphabet[b]) == false)
                {
                    cipherAlphabet[a] = sourceAlphabet[b];

                    usedCharacters.Add(sourceAlphabet[b]);
                    a++;
                }
            }

            return cipherAlphabet;
        }
    }
}
