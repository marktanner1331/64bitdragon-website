﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace crypto
{
    class Logger
    {
        private static FileStream currentStream;

        public static void createLog()
        {
            if (currentStream != null)
            {
                endLog();
            }

            string name = "output " + DateTime.Now.ToString("yy-MM-dd H-mm-ss") + ".txt";

            string filePath = Directory.GetCurrentDirectory() + "/" + name;
            if (Directory.Exists(filePath))
            {
                Directory.Delete(filePath);
            }

            currentStream = File.OpenWrite(filePath);
        }

        public static void endLog()
        {
            currentStream.Close();
            currentStream.Dispose();
            currentStream = null;
        }

        public static void writeLine(params object[] line)
        {
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < line.Length; i++)
            {
                if (i != 0)
                {
                    builder.Append(" ");
                }

                builder.Append(line[i]);
            }

            byte[] bytes = Encoding.ASCII.GetBytes(builder + Environment.NewLine);
            currentStream.Write(bytes, 0, bytes.Length);
        }

        public static void writeLine(params string[] line)
        {
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < line.Length; i++)
            {
                if (i != 0)
                {
                    builder.Append(" ");
                }

                builder.Append(line[i]);
            }

            byte[] bytes = Encoding.ASCII.GetBytes(builder + Environment.NewLine);
            currentStream.Write(bytes, 0, bytes.Length);
        }
    }
}
