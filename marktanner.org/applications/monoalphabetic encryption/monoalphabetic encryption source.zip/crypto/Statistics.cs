﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace crypto
{
    class Statistics
    {
        /// <summary>
        /// gets the standard deviation of the supplied frequencies by getting the variance
        /// and then square rooting it
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="frequencies"></param>
        /// <returns></returns>
        public static float getStandardDeviationFromFrequencies<T>(Dictionary<T, float> frequencies)
        {
            float variance = getVarianceFromFrequencies(frequencies);
            variance = (float)Math.Sqrt(variance);

            return variance;
        }

        /// <summary>
        /// gets the variance from the supplied frequencies
        /// the final division is using frequencies.length, not frequencies.length - 1
        /// this is because all of the individual frequencies will add up to a known number (probably 100)
        /// whether its a population or a sample, therefore the mean will always be the same
        /// which means there will be no bias in the variance and we dont need to adjust, i think.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="frequencies"></param>
        /// <returns></returns>
        public static float getVarianceFromFrequencies<T>(Dictionary<T, float> frequencies)
        {
            float mean = getArithmeticMeanFromFrequencies(frequencies);
            float[] differences = new float[frequencies.Count];

            int i = 0;
            foreach (KeyValuePair<T, float> keyValue in frequencies)
            {
                differences[i] = keyValue.Value- mean;
                i++;
            }

            for (i = 0; i < differences.Length; i++)
            {
                differences[i] = differences[i] * differences[i];
            }

            float sum = differences.Sum();
            sum /= differences.Length;

            return sum;
        }

        /// <summary>
        /// gets the arithmetic mean from the supplied set of frequencies
        /// </summary>
        /// <param name="frequencies"></param>
        /// <returns></returns>
        public static float getArithmeticMeanFromFrequencies<T>(Dictionary<T, float> frequencies)
        {
            float mean = 0;
            int i = 0;
            foreach (KeyValuePair<T, float> keyValue in frequencies)
            {
                mean += keyValue.Value;
                i++;
            }

            mean = mean / i;
            return mean;
        }

        public static void arithmeticMeanTest()
        {
            Dictionary<char, float> plainTextFrequencies = Statistics.getLowercaseLetterFrequencies();
            float mean = getArithmeticMeanFromFrequencies(plainTextFrequencies);
            Console.WriteLine(mean);
        }

        /// <summary>
        /// this method returns the range of the given frequencies, i.e. it returns the difference between
        /// the smallest and largest numbers
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="frequencies"></param>
        /// <returns></returns>
        public static float getRangeFromFrequencies<T>(Dictionary<T, float> frequencies)
        {
            float small = float.MaxValue;
            float big = float.MinValue;

            foreach (KeyValuePair<T, float> keyValue in frequencies)
            {
                if (keyValue.Value < small)
                {
                    small = keyValue.Value;
                }

                if (keyValue.Value > big)
                {
                    big = keyValue.Value;
                }
            }

            return big - small;
        }

        /// <summary>
        /// returns a dictionary where the keys are lowercase characters and the values are the frequency
        /// of the character in english, values are percent
        /// </summary>
        /// <returns></returns>
        public static Dictionary<char, float> getLowercaseLetterFrequencies()
        {
            Dictionary<char, float> dict = new Dictionary<char, float>();
            dict['a'] = 8.2f;
            dict['b'] = 1.5f;
            dict['c'] = 2.8f;
            dict['d'] = 4.3f;
            dict['e'] = 12.7f;
            dict['f'] = 2.2f;
            dict['g'] = 2.0f;
            dict['h'] = 6.1f;
            dict['i'] = 7.0f;
            dict['j'] = 0.2f;
            dict['k'] = 0.8f;
            dict['l'] = 4.0f;
            dict['m'] = 2.4f;
            dict['n'] = 6.7f;
            dict['o'] = 7.5f;
            dict['p'] = 1.9f;
            dict['q'] = 0.1f;
            dict['r'] = 6.0f;
            dict['s'] = 6.3f;
            dict['t'] = 9.1f;
            dict['u'] = 2.8f;
            dict['v'] = 1.0f;
            dict['w'] = 2.4f;
            dict['x'] = 0.2f;
            dict['y'] = 2.0f;
            dict['z'] = 0.1f;
            return dict;
        }

        public static void getLowercaseLetterFrequenciesTest()
        {
            Dictionary<char, float> frequencies = getLowercaseLetterFrequencies();
            foreach (KeyValuePair<char, float> keyValue in frequencies)
            {
                Console.WriteLine(keyValue);
            }
        }

        /// <summary>
        /// returns a dictionary where the key is the character and the value is the frequency of that character
        /// in the given text. frequencies are in percent.
        /// if a character is in 'characters' but not in the alphabet it will be ignored
        /// if a character is int he dictionary but not in 'characters' then its frequency will be 0
        /// </summary>
        /// <param name="characters"></param>
        /// <param name="alphabet"></param>
        /// <returns></returns>
        public static Dictionary<T, float> getFrequenciesOfCharacters<T>(T[] characters, T[] alphabet)
        {
            Dictionary<T, float> dict = new Dictionary<T, float>(alphabet.Length);
            HashSet<T> alphabetSet = new HashSet<T>(alphabet);

            for (int i = 0; i < alphabet.Length; i++)
            {
                dict[alphabet[i]] = 0;
            }

            int a = 0;
            for (int i = 0; i < characters.Length; i++)
            {
                if (alphabetSet.Contains(characters[i]))
                {
                    dict[characters[i]]++;
                    a++;
                }
            }

            float normalizer = 100f / a;
            Dictionary<T, float> normalized = new Dictionary<T, float>(alphabet.Length);

            foreach (KeyValuePair<T, float> keyValue in dict)
            {
                normalized[keyValue.Key] = keyValue.Value * normalizer;
            }

            return normalized;
        }

        public static void getFrequenciesOfCharactersTest()
        {
            char[] alphabet = PlainTextFactory.lowercaseAlphabet();
            char[] characters = PlainTextFactory.longStarWarsAllLower();

            Dictionary<char, float> frequencies = getFrequenciesOfCharacters(characters, alphabet);
            foreach (KeyValuePair<char, float> keyValue in frequencies)
            {
                Console.WriteLine(keyValue);
            }
        }
    }
}
