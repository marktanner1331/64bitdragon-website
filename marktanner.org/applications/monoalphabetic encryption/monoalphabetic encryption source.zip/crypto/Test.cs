﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace crypto
{
    class Test
    {
        public static void monoalphabeticSubstitutionAnalysisTest5()
        {
            
        }

        public static void monoalphabeticSubstitutionAnalysisTest4()
        {
            char[] alphabet = PlainTextFactory.lowercaseAlphabet();
            char[] key = CipherKeyFactory.getMonoalphabeticCipherKey(alphabet);
            char[] characters = PlainTextFactory.longStarWarsAllLower();
            char[] cipherText = MonoalphabeticSubstitution.encrypt(characters, alphabet, key);

            //Console.WriteLine(characters);
            key = null;
            characters = null;

            Dictionary<char, float> plainTextFrequencies = Statistics.getLowercaseLetterFrequencies();
            KeyValuePair<char, float>[] orderedPlainTextFrequencies = Primitives.sortFrequenciesDescending(plainTextFrequencies);

            Dictionary<char, float> cipherFrequencies = Statistics.getFrequenciesOfCharacters(cipherText, alphabet);
            KeyValuePair<char, float>[] orderedCipherTextFrequencies = Primitives.sortFrequenciesDescending(cipherFrequencies);

            KeyValuePair<char, float>[][] pairs = Primitives.getAllUnorderedPairs(cipherFrequencies);

            float[] distances = Primitives.getFrequencyDistancesForPairs(pairs);

            KeyValuePair<char, float>[][] orderedPairs = (KeyValuePair<char, float>[][])pairs.Clone();
            Primitives.sortByCorrespondingFrequencies(ref orderedPairs, ref distances);

            KeyValuePair<char, float>[][] pairsContainingI = Primitives.getPairsContaining(orderedPairs, 'i');

            Logger.createLog();
            for (int i = 0; i < pairsContainingI.Length; i++)
            {
                Logger.writeLine(pairsContainingI[i][0], pairsContainingI[i][1]);
            }
            Logger.endLog();

            bool[] switchedOn = new bool[orderedPairs.Length];
        }

        public static void monoalphabeticSubstitutionAnalysisTest3()
        {
            char[] alphabet = PlainTextFactory.lowercaseAlphabet();
            char[] key = CipherKeyFactory.getMonoalphabeticCipherKey(alphabet);
            char[] characters = PlainTextFactory.longStarWarsAllLower();
            char[] cipherText = MonoalphabeticSubstitution.encrypt(characters, alphabet, key);

            Console.WriteLine(characters);

            key = null;
            characters = null;

            Dictionary<char, float> plainTextFrequencies = Statistics.getLowercaseLetterFrequencies();
            KeyValuePair<char, float>[] orderedPlainTextFrequencies = Primitives.sortFrequenciesDescending(plainTextFrequencies);

            Dictionary<char, float> cipherFrequencies = Statistics.getFrequenciesOfCharacters(cipherText, alphabet);
            KeyValuePair<char, float>[] orderedCipherTextFrequencies = Primitives.sortFrequenciesDescending(cipherFrequencies);

            char[] frequencyOrderedPlainTextAlphabet = Primitives.convertFrequenciesToAlphabet(orderedPlainTextFrequencies);
            char[] frequencyOrderedCipherTextAlphabet = Primitives.convertFrequenciesToAlphabet(orderedCipherTextFrequencies);

            characters = MonoalphabeticSubstitution.decrypt(cipherText, frequencyOrderedPlainTextAlphabet, frequencyOrderedCipherTextAlphabet);
            Console.WriteLine(characters);
        }

        public static void monoalphabeticSubstitutionAnalysisTest2()
        {
            Dictionary<char, float> plainTextFrequencies = Statistics.getLowercaseLetterFrequencies();
            
            char[] alphabet = PlainTextFactory.lowercaseAlphabet();
            char[] characters = PlainTextFactory.longStarWarsAllLower();
            Dictionary<char, float> starWarsFrequencies = Statistics.getFrequenciesOfCharacters(characters, alphabet);

            Console.WriteLine(Statistics.getRangeFromFrequencies(plainTextFrequencies));
            Console.WriteLine(Statistics.getRangeFromFrequencies(starWarsFrequencies));
            Console.WriteLine();

            Console.WriteLine(Statistics.getVarianceFromFrequencies(plainTextFrequencies));
            Console.WriteLine(Statistics.getVarianceFromFrequencies(starWarsFrequencies));
            Console.WriteLine();

            Console.WriteLine(Statistics.getStandardDeviationFromFrequencies(plainTextFrequencies));
            Console.WriteLine(Statistics.getStandardDeviationFromFrequencies(starWarsFrequencies));
            Console.WriteLine();
        }

        public static void monoalphabeticSubstitutionAnalysisTest1()
        {
            Dictionary<char, float> plainTextFrequencies = Statistics.getLowercaseLetterFrequencies();

            char[] alphabet = PlainTextFactory.lowercaseAlphabet();
            char[] characters = PlainTextFactory.longStarWarsAllLower();
            Dictionary<char, float> starWarsFrequencies = Statistics.getFrequenciesOfCharacters(characters, alphabet);

            for (int i = 0; i < alphabet.Length; i++)
            {
                char c = alphabet[i];
                Console.WriteLine(c + ": " + plainTextFrequencies[c] + ", " + starWarsFrequencies[c]);
            }
        }

        public static void keyPhraseCipherTest()
        {
            char[] alphabet = PlainTextFactory.lowercaseAlphabet();
            char[] keyPhrase = PlainTextFactory.gooseAllLower();
            char[] key = CipherKeyFactory.getKeyPhraseCipherKey(keyPhrase, alphabet);

            Console.WriteLine(alphabet);
            Console.WriteLine(keyPhrase);
            Console.WriteLine(key);
        }

        public static void generalSubstitutionTest2()
        {
            char[] plainText = PlainTextFactory.shortStarWars();

            char[] alphabet = PlainTextFactory.allPrintableAsciiChars();
            char[] key = Primitives.knuthShuffle(alphabet);

            char[] cipherText = MonoalphabeticSubstitution.encrypt(plainText, alphabet, key);
            char[] plainText2 = MonoalphabeticSubstitution.decrypt(cipherText, alphabet, key);

            Console.WriteLine(alphabet);
            Console.WriteLine(key);
            Console.WriteLine(plainText);
            Console.WriteLine(cipherText);
            Console.WriteLine(plainText2);
        }

        public static void generalSubstitutionTest1()
        {
            char[] plainText = PlainTextFactory.shortStarWarsAllLower();

            char[] alphabet = PlainTextFactory.lowercaseAlphabet();
            char[] key = Primitives.knuthShuffle(alphabet);

            char[] cipherText = MonoalphabeticSubstitution.encrypt(plainText, alphabet, key);
            char[] plainText2 = MonoalphabeticSubstitution.decrypt(cipherText, alphabet, key);

            Console.WriteLine(alphabet);
            Console.WriteLine(key);
            Console.WriteLine(plainText);
            Console.WriteLine(cipherText);
            Console.WriteLine(plainText2);
        }

        public static void railFenceTranspositionTest1()
        {
            char[] plainText = PlainTextFactory.lowercaseAlphabet();
            Console.WriteLine(plainText);

            char[] cipherText = RailFenceTransposition.encrypt(plainText, 2);
            Console.WriteLine(cipherText);

            char[] plainText2 = RailFenceTransposition.decrypt(cipherText, 2);
            Console.WriteLine(plainText2);
        }

        public static void caesarCipherTest1()
        {
            char[] plainText = PlainTextFactory.shortStarWarsAllLower();

            char[] alphabet = PlainTextFactory.lowercaseAlphabet();
            char[] key = CipherKeyFactory.getCaesarCipherKey(alphabet);

            char[] cipherText = MonoalphabeticSubstitution.encrypt(plainText, alphabet, key);
            char[] plainText2 = MonoalphabeticSubstitution.decrypt(cipherText, alphabet, key);

            Console.WriteLine(alphabet);
            Console.WriteLine(key);
            Console.WriteLine(plainText);
            Console.WriteLine(cipherText);
            Console.WriteLine(plainText2);
        }

        public static void caesarCipherTest2()
        {
            char[] plainText = PlainTextFactory.shortStarWars();

            char[] alphabet = PlainTextFactory.allPrintableAsciiChars();
            char[] key = CipherKeyFactory.getCaesarCipherKey(alphabet);

            char[] cipherText = MonoalphabeticSubstitution.encrypt(plainText, alphabet, key);
            char[] plainText2 = MonoalphabeticSubstitution.decrypt(cipherText, alphabet, key);

            Console.WriteLine(alphabet);
            Console.WriteLine(key);
            Console.WriteLine(plainText);
            Console.WriteLine(cipherText);
            Console.WriteLine(plainText2);
        }
    }
}
