﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace crypto
{
    class Primitives
    {
        /// <summary>
        /// calculates the binomial coefficient where k = 2
        /// </summary>
        /// <param name="n"></param>
        /// <returns></returns>
        public static int nChoose2(int n)
        {
            return n * (n - 1) / 2;
        }

        /// <summary>
        /// makes a shallow copy of the source and then performs a knuth shuffle 
        /// with the built in random generator
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="source"></param>
        /// <returns></returns>
        public static T[] knuthShuffle<T>(T[] source)
        {
            source = (T[])source.Clone();
            Random rand = new Random();

            for (int i = 0; i < source.Length; i++)
            {
                int j = rand.Next(i, source.Length);

                //exchange the chars at i and j
                T temp = source[i];
                source[i] = source[j];
                source[j] = temp;
            }

            return source;
        }

        public static void knuthShuffleTest()
        {
            char[] plainText = PlainTextFactory.lowercaseAlphabet();
            Console.WriteLine(plainText);

            char[] shuffledPlainText = knuthShuffle(plainText);
            Console.WriteLine(shuffledPlainText);
        }

        /// <summary>
        /// adds the second array to the end of the first
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="first"></param>
        /// <param name="second"></param>
        /// <returns></returns>
        public static T[] combineArrays<T>(T[] first, T[] second)
        {
            T[] combined = new T[first.Length + second.Length];
            for (int i = 0; i < first.Length; i++)
            {
                combined[i] = first[i];
            }

            for (int i = 0; i < second.Length; i++)
            {
                combined[i + first.Length] = second[i];
            }

            return combined;
        }

        /// <summary>
        /// adds all of the arrays in the specified array of arrays,
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="arrays"></param>
        /// <returns></returns>
        public static T[] combineArrays<T>(T[][] arrays)
        {
            int totalLength = 0;
            for (int i = 0; i < arrays.Length; i++)
            {
                totalLength += arrays[i].Length;
            }

            T[] combined = new T[totalLength];

            int offset = 0;
            for (int i = 0; i < arrays.Length; i++)
            {
                for (int a = 0; a < arrays[i].Length; a++)
                {
                    combined[offset] = arrays[i][a];
                    offset++;
                }
            }

            return combined;
        }

        /// <summary>
        /// performs a shallow clone on the source and then shifts the elements by the specified amount
        /// supports negative shift amounts
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="source"></param>
        /// <param name="shiftAmount"></param>
        /// <returns></returns>
        public static T[] shift<T>(T[] source, int shiftAmount)
        {
            T[] dest = new T[source.Length];

            for (int i = 0; i < source.Length; i++)
            {
                int shiftedI = mod((i + shiftAmount), source.Length);
                dest[shiftedI] = source[i];
            }

            return dest;
        }

        /// <summary>
        /// c# doesnt actually do a mod when you use the % operator, it does a remainder.
        /// this means that modding negative numbers can lead to a negative result, 
        /// this code does a proper mod
        /// </summary>
        /// <param name="x">the dividend</param>
        /// <param name="m">the divisor</param>
        /// <returns></returns>
        public static int mod(int a, int n)
        {
            int r = a % n;
            return r < 0 ? r + n : r;
        }

        /// <summary>
        /// like subString() but for arrays
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="source"></param>
        /// <returns></returns>
        public static T[] subArray<T>(T[] source, int index, int count)
        {
            T[] dest = new T[count];
            Array.Copy(source, index, dest, 0, count);
            return dest;
        }

        public static void shiftTest()
        {
            char[] plainText = PlainTextFactory.lowercaseAlphabet();
            Console.WriteLine(plainText);

            char[] shiftedText = shift(plainText, 3);
            Console.WriteLine(shiftedText);

            char[] shiftedText2 = shift(plainText, -3);
            Console.WriteLine(shiftedText2);
        }

        /// <summary>
        /// given an array of booleans, this method treats it like an integer of bits, and increments that integer
        /// this method modifies the argument that it passed to it, rather than returning a modified copy
        /// the first boolean in the array is treated as the most significant bit and the last boolean in the array is the least 
        /// significant bit
        /// </summary>
        /// <param name="switches"></param>
        public static void incrementSwitches(ref bool[] switches)
        {
            bool overflow = false;

            for (int i = switches.Length - 1; i <= 0; i--)
            {
                //i realize that this could be heavily consolidated
                if (switches[i] == true)
                {
                    switches[i] = false;
                    overflow = true;
                }
                else
                {
                    switches[i] = true;
                    overflow = false;
                }

                if (overflow == false)
                {
                    break;
                }
            }
        }

        /// <summary>
        /// makes a shallow copy of the plaintext and performs a substitution on that plaintext 
        /// using the substitution dictionary provided, if a plaintext character isnt in the
        /// substitution dictionary then the plaintext character is substituted with itself
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="plainText"></param>
        /// <param name="substitutionDictionary"></param>
        /// <returns></returns>
        public static T[] performSubstitution<T>(T[] plainText, Dictionary<T, T> substitutionDictionary)
        {
            T[] cipherText = new T[plainText.Length];

            for (int i = 0; i < plainText.Length; i++)
            {
                if (substitutionDictionary.ContainsKey(plainText[i]))
                {
                    cipherText[i] = substitutionDictionary[plainText[i]];
                }
                else
                {
                    cipherText[i] = plainText[i];
                }
            }

            return cipherText;
        }
        
        /// <summary>
        /// creates a dictionary using the letters from the plaintext alphabet as the keys and letters from
        /// the cipher alphabet as the values
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="plainAlphabet"></param>
        /// <param name="cipherAlphabet"></param>
        /// <returns></returns>
        public static Dictionary<T, T> createSubstitutionDictionary<T>(T[] plainAlphabet, T[] cipherAlphabet)
        {
            Dictionary<T, T> dict = new Dictionary<T, T>(plainAlphabet.Length);

            for (int i = 0; i < plainAlphabet.Length; i++)
            {
                dict[plainAlphabet[i]] = cipherAlphabet[i];
            }

            return dict;
        }

        /// <summary>
        /// returns every possible pair of letters as an array of arrays
        /// the sub arrays have always got 2 items, 
        /// the pair is unordered, e.g. [a, b] == [b, a]
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="frequencies"></param>
        /// <returns></returns>
        public static KeyValuePair<T, float>[][] getAllUnorderedPairs<T>(Dictionary<T, float> frequencies)
        {
            //first we get it in a nicer format
            KeyValuePair<T, float>[] frequenciesArray = new KeyValuePair<T, float>[frequencies.Count];

            int i = 0;
            foreach (KeyValuePair<T, float> keyValue in frequencies)
            {
                frequenciesArray[i] = keyValue;
                i++;
            }

            //now we can make all possible pairs
            KeyValuePair<T, float>[][] pairs = new KeyValuePair<T, float>[nChoose2(frequenciesArray.Length)][];

            //hint, the last iteration of this loop wont do anything
            i = 0;
            for (int j = 0; j < frequenciesArray.Length; j++)
            {
                for (int k = j + 1; k < frequenciesArray.Length; k++)
                {
                    KeyValuePair<T, float>[] pair = { frequenciesArray[j], frequenciesArray[k] };
                    pairs[i] = pair;
                    i++;
                }
            }

            return pairs;
        }

        /// <summary>
        /// returns all pairs that contain the needle
        /// if the haystack is in order then the return array will also be in order
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="haystack"></param>
        /// <param name="needle"></param>
        /// <returns></returns>
        public static KeyValuePair<T, float>[][] getPairsContaining<T>(KeyValuePair<T, float>[][] haystack, T needle) where T : IEquatable<T>
        {
            List<KeyValuePair<T, float>[]> pairs = new List<KeyValuePair<T, float>[]>();
            for (int i = 0; i < haystack.Length; i++)
            {
                if (haystack[i][0].Key.Equals(needle) || haystack[i][1].Key.Equals(needle))
                {
                    pairs.Add(haystack[i]);
                }
            }

            return pairs.ToArray();
        }

        /// <summary>
        /// sorts the source by examining the frequencies, basically sorts the frequencies but includes the source
        /// in all the swaps
        /// this method modifies the existing arrays
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="source"></param>
        /// <param name="correspondingFrequencies"></param>
        /// <returns></returns>
        public static void sortByCorrespondingFrequencies<T>(ref T[] source, ref float[] correspondingFrequencies)
        {
            //using insertion sort
            for(int i = 0;i < correspondingFrequencies.Length;i++)
            {
                float x1 = correspondingFrequencies[i];
                T x2 = source[i];
                int j = i;
                while(j > 0 && correspondingFrequencies[j - 1] > x1)
                {
                    correspondingFrequencies[j] = correspondingFrequencies[j - 1];
                    source[j] = source[j - 1];
                    j = j - 1;
                }

                correspondingFrequencies[j] = x1;
                source[j] = x2;
            }

            //we want it in descending order
            source = source.Reverse().ToArray();
            correspondingFrequencies = correspondingFrequencies.Reverse().ToArray();
        }

        /// <summary>
        /// given an array of pairs of frequencies, this method calculates the distance between those frequencies
        /// for each pair, and returns them as an array
        /// </summary>
        /// <param name="pairs"></param>
        /// <returns></returns>
        public static float[] getFrequencyDistancesForPairs<T>(KeyValuePair<T, float>[][] pairs)
        {
            float[] distances = new float[pairs.Length];
            for (int i = 0; i < pairs.Length; i++)
            {
                distances[i] = getFrequencyDistanceForPair(pairs[i]);
            }

            return distances;
        }

        /// <summary>
        /// given a pair of frequencies, this method calculates the distance between them
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="pair"></param>
        /// <returns></returns>
        public static float getFrequencyDistanceForPair<T>(KeyValuePair<T, float>[] pair)
        {
            float ret = Math.Abs(pair[0].Value - pair[1].Value);
            return ret;
        }

        /// <summary>
        /// returns an array of the frequencies with the most frequent first and the least frequent last
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="frequencies"></param>
        /// <returns></returns>
        public static KeyValuePair<T, float>[] sortFrequenciesDescending<T>(Dictionary<T, float> frequencies)
        {
            KeyValuePair<T, float>[] orderedFrequencies = new KeyValuePair<T, float>[frequencies.Count];

            int i = 0;
            foreach (KeyValuePair<T, float> keyValue in frequencies)
            {
                orderedFrequencies[i] = keyValue;
                i++;
            }

            orderedFrequencies = (from keyValue in orderedFrequencies
                                  orderby keyValue.Value descending
                                  select keyValue).ToArray();

            return orderedFrequencies;
        }

        /// <summary>
        /// converts an array of key value pairs into an array of keys. 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="frequencies"></param>
        /// <returns></returns>
        public static T[] convertFrequenciesToAlphabet<T>(KeyValuePair<T, float>[] frequencies)
        {
            T[] alphabet = new T[frequencies.Length];

            for (int i = 0; i < alphabet.Length; i++)
            {
                alphabet[i] = frequencies[i].Key;
            }

            return alphabet;
        }
    }
}
