﻿namespace monoalphabetic_encryptor
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.keyLabel = new System.Windows.Forms.Label();
            this.keyField = new System.Windows.Forms.TextBox();
            this.plainTextLabel = new System.Windows.Forms.Label();
            this.plainTextField = new System.Windows.Forms.TextBox();
            this.encryptButton = new System.Windows.Forms.Button();
            this.decryptButton = new System.Windows.Forms.Button();
            this.cipherField = new System.Windows.Forms.TextBox();
            this.cipherLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // keyLabel
            // 
            this.keyLabel.AutoSize = true;
            this.keyLabel.Location = new System.Drawing.Point(12, 470);
            this.keyLabel.Name = "keyLabel";
            this.keyLabel.Size = new System.Drawing.Size(52, 26);
            this.keyLabel.TabIndex = 0;
            this.keyLabel.Text = "key:";
            // 
            // keyField
            // 
            this.keyField.BackColor = System.Drawing.Color.White;
            this.keyField.Location = new System.Drawing.Point(70, 470);
            this.keyField.Name = "keyField";
            this.keyField.Size = new System.Drawing.Size(909, 31);
            this.keyField.TabIndex = 3;
            // 
            // plainTextLabel
            // 
            this.plainTextLabel.AutoSize = true;
            this.plainTextLabel.Location = new System.Drawing.Point(12, 9);
            this.plainTextLabel.Name = "plainTextLabel";
            this.plainTextLabel.Size = new System.Drawing.Size(108, 26);
            this.plainTextLabel.TabIndex = 2;
            this.plainTextLabel.Text = "Plain Text";
            // 
            // plainTextField
            // 
            this.plainTextField.Location = new System.Drawing.Point(12, 38);
            this.plainTextField.Multiline = true;
            this.plainTextField.Name = "plainTextField";
            this.plainTextField.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.plainTextField.Size = new System.Drawing.Size(853, 400);
            this.plainTextField.TabIndex = 1;
            // 
            // encryptButton
            // 
            this.encryptButton.Location = new System.Drawing.Point(871, 175);
            this.encryptButton.Name = "encryptButton";
            this.encryptButton.Size = new System.Drawing.Size(108, 82);
            this.encryptButton.TabIndex = 4;
            this.encryptButton.Text = "Encrypt";
            this.encryptButton.UseVisualStyleBackColor = true;
            this.encryptButton.Click += new System.EventHandler(this.encryptButton_Click);
            // 
            // decryptButton
            // 
            this.decryptButton.Location = new System.Drawing.Point(871, 687);
            this.decryptButton.Name = "decryptButton";
            this.decryptButton.Size = new System.Drawing.Size(108, 82);
            this.decryptButton.TabIndex = 7;
            this.decryptButton.Text = "Decrypt";
            this.decryptButton.UseVisualStyleBackColor = true;
            this.decryptButton.Click += new System.EventHandler(this.decryptButton_Click);
            // 
            // cipherField
            // 
            this.cipherField.Location = new System.Drawing.Point(12, 550);
            this.cipherField.Multiline = true;
            this.cipherField.Name = "cipherField";
            this.cipherField.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.cipherField.Size = new System.Drawing.Size(853, 400);
            this.cipherField.TabIndex = 6;
            // 
            // cipherLabel
            // 
            this.cipherLabel.AutoSize = true;
            this.cipherLabel.Location = new System.Drawing.Point(12, 521);
            this.cipherLabel.Name = "cipherLabel";
            this.cipherLabel.Size = new System.Drawing.Size(123, 26);
            this.cipherLabel.TabIndex = 5;
            this.cipherLabel.Text = "Cipher Text";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(991, 970);
            this.Controls.Add(this.decryptButton);
            this.Controls.Add(this.cipherField);
            this.Controls.Add(this.cipherLabel);
            this.Controls.Add(this.encryptButton);
            this.Controls.Add(this.plainTextField);
            this.Controls.Add(this.plainTextLabel);
            this.Controls.Add(this.keyField);
            this.Controls.Add(this.keyLabel);
            this.Name = "Form1";
            this.Text = "Monoalphabetic Encryption";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label keyLabel;
        private System.Windows.Forms.TextBox keyField;
        private System.Windows.Forms.Label plainTextLabel;
        private System.Windows.Forms.TextBox plainTextField;
        private System.Windows.Forms.Button encryptButton;
        private System.Windows.Forms.Button decryptButton;
        private System.Windows.Forms.TextBox cipherField;
        private System.Windows.Forms.Label cipherLabel;
    }
}

