﻿using crypto;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace monoalphabetic_encryptor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            OnResize(null);

        }

        protected override void OnResize(EventArgs e)
        {
            int fieldHeight = ClientSize.Height;
            fieldHeight -= 3 * 26; //the 3 labels
            fieldHeight -= 3 * 12; //three paddings
            fieldHeight /= 2;

            plainTextLabel.Location = new Point(12, 12);
            
            plainTextField.Location = new Point(12, 38);
            plainTextField.Size = new Size(ClientSize.Width - encryptButton.Width - 12 - 12 - 12, fieldHeight);

            encryptButton.Location = new Point(ClientSize.Width - encryptButton.Width - 12, plainTextField.Location.Y + plainTextField.Height / 2 - encryptButton.Height / 2);

            keyLabel.Location = new Point(12, plainTextField.Location.Y + plainTextField.Height + 12);
            keyField.Location = new Point(keyLabel.Location.X + keyLabel.Width + 12, keyLabel.Location.Y);
            keyField.Width = ClientSize.Width - 12 - keyField.Location.X;

            cipherLabel.Location = new Point(12, keyField.Location.Y + keyField.Height + 12);

            cipherField.Location = new Point(12, cipherLabel.Location.Y + cipherLabel.Height + 12);
            cipherField.Width = plainTextField.Width;
            cipherField.Height = plainTextField.Height;

            decryptButton.Location = new Point(ClientSize.Width - decryptButton.Width - 12, cipherField.Location.Y + cipherField.Height / 2 - decryptButton.Height / 2);

        }

        private void encryptButton_Click(object sender, EventArgs e)
        {
            char[] plainTextAlphabet = PlainTextFactory.allPrintableAsciiChars();
            char[] plainText = plainTextField.Text.ToCharArray();

            char[] key;
            if (keyField.Text.Length == plainTextAlphabet.Length)
            {
                key = keyField.Text.ToCharArray();
            }
            else
            {
                key = CipherKeyFactory.getMonoalphabeticCipherKey(plainTextAlphabet);
                keyField.Text = new string(key);
            }

            
            char[] cipherText = MonoalphabeticSubstitution.encrypt(plainText, plainTextAlphabet, key);
            cipherField.Text = new string(cipherText);
        }

        private void decryptButton_Click(object sender, EventArgs e)
        {
            char[] plainTextAlphabet = PlainTextFactory.allPrintableAsciiChars();
            char[] cipherText = cipherField.Text.ToCharArray();

            char[] key;
            if (keyField.Text.Length == plainTextAlphabet.Length)
            {
                key = keyField.Text.ToCharArray();
            }
            else
            {
                MessageBox.Show("invalid key, must include entire printable ascii range");
                return;
            }

            char[] plainText = MonoalphabeticSubstitution.decrypt(cipherText, plainTextAlphabet, key);
            plainTextField.Text = new string(plainText);
        }
    }
}
