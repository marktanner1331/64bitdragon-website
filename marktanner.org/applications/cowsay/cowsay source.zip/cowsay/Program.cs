﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cowsay
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length != 1)
            {
                return;
            }

            
            string text = args[0];
            int length = text.Length + 6;

            Console.Write("\t ");
            printNTimes("_", length);
            Console.Write(" \n");

            Console.Write("\t/");
            printNTimes(" ", length);
            Console.Write("\\\n");

            Console.Write("\t|");
            printNTimes(" ", length);
            Console.Write("|\n");

            Console.Write("\t|   ");
            Console.Write(text);
            Console.Write("   |\n");

            Console.Write("\t|");
            printNTimes(" ", length);
            Console.Write("|\n");

            Console.Write("\t\\");
            printNTimes(" ", length);
            Console.Write("/\n");

            Console.Write("\t ");
            printNTimes("-", length);
            Console.Write(" \n");

            printCow();
        }

        private static void printCow()
        {
            Console.Write("\t\t"); Console.WriteLine(@"   \   ^__^");
            Console.Write("\t\t"); Console.WriteLine(@"    \  (oo)\_______");
            Console.Write("\t\t"); Console.WriteLine(@"       (__)\       )\/\");
            Console.Write("\t\t"); Console.WriteLine(@"           ||----w |");
            Console.Write("\t\t"); Console.WriteLine(@"           ||     ||");
        }

        static void printNTimes(string s, int count)
        {
            for (int i = 0; i < count; i++)
            {
                Console.Write(s);
            }
        }
    }
}
